# Submitting a patch

* Fork the repo on github
* Make a [topic branch](https://github.com/dchelimsky/rspec/wiki/Topic-Branches#using-topic-branches-when-contributing-patches) and start hacking
* Submit a pull request based off your topic branch

Small focused patches are preferred.

# General style notes

Following the coding conventions/styles used in the syntastic core:

* Use 4 space indents.
* Don't use abbreviated keywords - e.g. use `endfunction`, not `endfun` (there's always room for more fun!).
* Dont use `l:` prefixes for variables unless actually required (i.e. almost never).
* Code for maintainabiliy. We would rather a function be a couple of lines longer and have (for example) some [explaining variables](http://www.refactoring.com/catalog/introduceExplainingVariable.html) to aid readability.

# Syntax checker style notes

The preferred style for error format strings is one "clause" per line. E.g.
(from the coffeelint checker):

    let errorformat = '%E%f:%l:%c: %trror: %m,' .
                \ 'Syntax%trror: In %f\, %m on line %l,' .
                \ '%EError: In %f\, Parse error on line %l: %m,' .
                \ '%EError: In %f\, %m on line %l,' .
                \ '%W%f(%l): lint warning: %m,' .
                \ '%W%f(%l): warning: %m,' .
                \ '%E%f(%l): SyntaxError: %m,' .
                \ '%-Z%p^,' .
                \ '%-G%.%#'


